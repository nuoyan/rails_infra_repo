

unsigned int fnv_hash(const void* key, int length, unsigned int seed);